<?php
header("Location: http://www.amabine.com");
?>