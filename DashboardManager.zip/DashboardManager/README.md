<!-- 

#############################################################
#					PACKAGE DETAILS 						#
#############################################################
-- Name 			| Dashboard Manager Version 1.0 [ALPHA]	#
-- Latest Update	| 11 December 2018						#
-- Copyright		| CoumpoundCode | Coso					#
#############################################################
#				ABOUT  DEVELOPER							#	
#############################################################
-- Name :		|	Mwanza Jason Blessed 					#
-- Github :		|	blessedjasonmwanza 						#
-- Twitter:		|	@mwanzabj								#
-- instagram:	|	@mwanzabj								#
-- email: 		|	mwanzabj@gmail.com 						#
#############################################################


#############################################################
#					INSTALLATION 							#
#					HOW TO INSTALL 							#
#############################################################
#
####################::::NB:::################################
-- MAKE SURE THE FOLDER WHERE THIS FILE IS LOCATED IS 		#
-- COPYED OR MOVED INTO A FOLDER NAMED 'htdocs'				#
-- ON WINDOWS OS, THIS FOLDER IS LOCATED ON 				#
-- C:\xampp\htdocs 											#
-- OR IN YOUR PROJECT FOLDER LOCATED IN 'htdocs' OF THE		#
-- 'xamp' INSTALLATION PATH									#
#############################################################

-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9
-- Database: `admin`

STEP 1: 

-- ON YOUR MACHINE INSTALL => 'XAMP CONTROL' |or| any PHP SERVER
-- CASE YOU INSTALL XAMP CONTROL 
--START XAMP CONTROL PANEL AND CHECK OR START 
-- 'Apeche' and 'MySQL' IN YOUR PANEL WINDOW. 
-- NEXT, USE THIS LINK TO CREATE A NEW DATABASE
-- http://localhost/phpmyadmin

STEP 2:

-- CREATE A NEW DATABASE AND  NAME IT (GIVE IT A NAME)  'admin'

STEP 3: 

-- CLICK ON 'import' & IMPORT A FILE STORED IN A FOLDER NAMED 
-- 'DB_FILE' LOCATED IN THE CURRENT DIRECTORY.

FINALE STEP:
-- PROVIDED THAT THIS PACKAGE WAS MOVED OR COPYED TO
-- C:\xampp\htdocs
-- i.e C:\xampp\htdocs\admin
-- OPEN YOUR BROWSER AND USE THIS LINK TO TEST IF THE 
-- THE CONFIGURATION WAS MADE SUCESSFULLY 



-- FOR QUERIES CONTACT THE DEVELOPER USING THE DETAILES PROVIDED ABOVE
 -->