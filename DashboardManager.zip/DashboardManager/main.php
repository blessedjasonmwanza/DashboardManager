		<a href=<?php echo '?page=visitors'; ?>><span class="tab1">
			<i class="fa fa-arrows fa-3x"></i>
			<label class="num1"><?php visitors();?></label>
			<label class="num12">Visitors</label>
		</span></a>		

		<a href=<?php echo '?page=messages'; ?>><span class="tab1">
			<i class="fa fa-envelope-o fa-3x"></i>
			<label class="num1"><?php msgtotal(); ?></label>
			<label class="num12">messages</label>
		</span></a>

		<a href=<?php echo '?page=notifications'; ?>><span class="tab1">
			<i class="fa fa-bell-o fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Notifications</label>
		</span></a>



		<a href=<?php echo '?page=users'; ?>><span class="tab1">
			<i class="fa fa-users fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Users</label>
		</span></a>

		<a href=<?php echo '?page=epigie'; ?>><span class="tab1">
			<i class="fa fa-globe fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Site</label>
		</span></a>

		<a href=<?php echo '?page=settings'; ?>><span class="tab1">
			<i class="fa fa-cogs fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Settings</label>
		</span></a>


		<a href=<?php echo '?page=pages'; ?>><span class="tab1">
			<i class="fa fa-flag fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">0</label>
		</span></a>

		<a href=<?php echo '?page=files'; ?>><span class="tab1">
			<i class="fa fa-file fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Files</label>
		</span></a>

		
		<a href=<?php echo '?page=stock'; ?>><span class="tab1">
			<i class="fa fa-cubes fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Stock</label>
		</span></a>

		<a href=<?php echo '?page=admins'; ?>><span class="tab1">
			<i class="fa fa-sitemap fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Admins</label>
		</span></a>
		<a href=<?php echo '?page=account'; ?>><span class="tab1">
			<i class="fa fa-lock fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Account</label>
		</span></a>
		<a href=<?php echo '?page=feed'; ?>><span class="tab1">
			<i class="fa fa-rss fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Feed</label>
		</span></a>

		<a href=<?php echo '?page=facebook'; ?>><span class="tab1">
			<i class="fa fa-facebook-square fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Facebook</label>
		</span></a>
		<a href="#"><span class="tab1">
			<i class="fa fa-twitter fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Twitter</label>
		</span></a>
		<a href="#"><span class="tab1">
			<i class="fa fa-linkedin fa-3x"></i>
			<label class="num1">0</label>
			<label class="num12">Linked in</label>
		</span></a>